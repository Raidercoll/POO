public enum NomeMoeda {
    UmReal, Cinquenta, VinteCinco, Dez, Cinco, Um
}